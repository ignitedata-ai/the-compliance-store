<?php
/**
 * Class that handles specific [vc_rev_slider] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/rev_slider_vc.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Rev_Slider_Vc
 */
class WPBakeryShortCode_Rev_Slider_Vc extends WPBakeryShortCode {
}
