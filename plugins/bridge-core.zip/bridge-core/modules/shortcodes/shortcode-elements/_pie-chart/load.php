<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_pie-chart/pie-chart.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_pie-chart/custom-styles/custom-styles.php';