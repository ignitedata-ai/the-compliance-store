<?php

$i = 1;
while ($i <= $columns) {
    $i++;
    if ($columns != 1) { ?>
        <div class='filler'></div>
    <?php }
}