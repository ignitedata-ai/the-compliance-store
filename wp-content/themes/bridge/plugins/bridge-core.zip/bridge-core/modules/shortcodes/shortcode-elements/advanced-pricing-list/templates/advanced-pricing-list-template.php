<div class="qode-advanced-pricing-list">
	<div class="qode-apl-header">
		<div class="qode-apl-title-holder">
			<<?php echo bridge_qode_get_escape_title_tag($list_title_tag); ?> class="qode-apl-title" <?php bridge_qode_inline_style($list_title_style); ?>>
				<?php echo esc_attr($list_title); ?>
			</<?php echo bridge_qode_get_escape_title_tag($list_title_tag); ?>>
		</div>
	</div>
	<div class="qode-apl-items">
		<?php
		if( is_array( $pricing_items ) && count( $pricing_items ) > 0 ) {
			foreach($pricing_items as $pricing_item):?>
				<div class="qode-apl-item">
					<div class="qode-apl-item-top">
						<<?php echo bridge_qode_get_escape_title_tag($item_title_tag); ?> class="qode-apl-item-title" <?php bridge_qode_inline_style($item_title_style) ?>>
							<?php if( ! empty( $pricing_item['item_title'] ) ) {
								echo esc_attr($pricing_item['item_title']);
							} ?>
						</<?php echo bridge_qode_get_escape_title_tag($item_title_tag); ?>>
						<div class="qode-apl-line" <?php bridge_qode_inline_style($line_style) ?>></div>
						<<?php echo bridge_qode_get_escape_title_tag($item_title_tag); ?> class="qode-apl-item-price" <?php bridge_qode_inline_style($item_title_style) ?>>
							<?php if( ! empty( $pricing_item['item_price'] ) ) {
								echo esc_attr($pricing_item['item_price']);
							} ?>
						</<?php echo bridge_qode_get_escape_title_tag($item_title_tag); ?>>
					</div>
					<?php if( ! empty( $pricing_item['item_description'] ) ) { ?>
						<div class="qode-apl-item-bottom">
							<div class="qode-apl-item-description" <?php bridge_qode_inline_style($item_description_style) ?>>
								<?php echo esc_attr($pricing_item['item_description']); ?>
							</div>
						</div>
					<?php } ?>
				</div>
			<?php endforeach;
		} ?>
	</div>
</div>