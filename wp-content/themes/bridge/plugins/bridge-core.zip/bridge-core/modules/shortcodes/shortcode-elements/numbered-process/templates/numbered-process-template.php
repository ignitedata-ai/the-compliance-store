<div <?php bridge_qode_class_attribute($holder_classes); ?>>
	<div class="qode-numbered-process-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>