<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_testimonials-carousel/testimonials-carousel.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_testimonials-carousel/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_testimonials-carousel/custom-styles/custom-styles.php';