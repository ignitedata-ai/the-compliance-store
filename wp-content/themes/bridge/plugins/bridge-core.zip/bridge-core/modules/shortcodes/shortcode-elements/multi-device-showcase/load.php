<?php
include_once BRIDGE_CORE_SHORTCODES_PATH.'/multi-device-showcase/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/multi-device-showcase/multi-device-showcase.php';
